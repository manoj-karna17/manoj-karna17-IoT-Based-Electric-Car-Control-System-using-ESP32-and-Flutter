import 'package:flutter/material.dart';
import 'package:web_socket_channel/web_socket_channel.dart';
import 'dart:convert';

void main() {
  runApp(CarControllerApp());
}

class CarControllerApp extends StatelessWidget {
  const CarControllerApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'IoT Car Controller',
      theme: ThemeData(
        primarySwatch: Colors.blue,
        brightness: Brightness.dark,
      ),
      home: CarControllerHome(),
    );
  }
}

class CarControllerHome extends StatefulWidget {
  const CarControllerHome({super.key});

  @override
  _CarControllerHomeState createState() => _CarControllerHomeState();
}

class _CarControllerHomeState extends State<CarControllerHome> {
  WebSocketChannel? channel;
  bool isConnected = false;
  String connectionStatus = "Disconnected";
  double speed = 200;
  String esp32IP = "192.168.1.100"; // Change this to your ESP32's IP
  
  // Control states
  bool forward = false;
  bool backward = false;
  bool left = false;
  bool right = false;

  @override
  void initState() {
    super.initState();
  }

  void connectToESP32() {
    try {
      channel = WebSocketChannel.connect(
        Uri.parse('ws://$esp32IP:81'),
      );
      
      channel!.stream.listen(
        (data) {
          print('Received: $data');
          // Handle responses from ESP32
          var response = json.decode(data);
          if (response['status'] == 'connected') {
            setState(() {
              isConnected = true;
              connectionStatus = "Connected";
            });
          }
        },
        onError: (error) {
          print('WebSocket error: $error');
          setState(() {
            isConnected = false;
            connectionStatus = "Connection Error";
          });
        },
        onDone: () {
          setState(() {
            isConnected = false;
            connectionStatus = "Disconnected";
          });
        },
      );
      
    } catch (e) {
      print('Connection failed: $e');
      setState(() {
        isConnected = false;
        connectionStatus = "Failed to Connect";
      });
    }
  }

  void disconnect() {
    channel?.sink.close();
    setState(() {
      isConnected = false;
      connectionStatus = "Disconnected";
      forward = backward = left = right = false;
    });
  }

  void sendCommand(String command, Map<String, dynamic> data) {
    if (isConnected && channel != null) {
      var message = {
        'command': command,
        ...data,
      };
      channel!.sink.add(json.encode(message));
    }
  }

  void sendMoveCommand() {
    sendCommand('move', {
      'forward': forward,
      'backward': backward,
      'left': left,
      'right': right,
    });
  }

  void sendSpeedCommand() {
    sendCommand('speed', {'value': speed.round()});
  }

  void emergencyStop() {
    setState(() {
      forward = backward = left = right = false;
    });
    sendCommand('stop', {});
  }

  @override
  void dispose() {
    channel?.sink.close();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('IoT Car Controller'),
        backgroundColor: Colors.blueGrey[800],
      ),
      body: Container(
        decoration: BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [Colors.blueGrey[900]!, Colors.black87],
          ),
        ),
        child: Padding(
          padding: EdgeInsets.all(16.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              // Connection Panel
              Card(
                color: Colors.blueGrey[800],
                child: Padding(
                  padding: EdgeInsets.all(16.0),
                  child: Column(
                    children: [
                      Row(
                        children: [
                          Icon(
                            isConnected ? Icons.wifi : Icons.wifi_off,
                            color: isConnected ? Colors.green : Colors.red,
                          ),
                          SizedBox(width: 8),
                          Text(
                            connectionStatus,
                            style: TextStyle(
                              color: isConnected ? Colors.green : Colors.red,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                        ],
                      ),
                      SizedBox(height: 10),
                      TextField(
                        decoration: InputDecoration(
                          labelText: 'ESP32 IP Address',
                          hintText: '192.168.1.100',
                          border: OutlineInputBorder(),
                        ),
                        onChanged: (value) {
                          esp32IP = value;
                        },
                        controller: TextEditingController(text: esp32IP),
                      ),
                      SizedBox(height: 10),
                      Row(
                        children: [
                          Expanded(
                            child: ElevatedButton(
                              onPressed: isConnected ? null : connectToESP32,
                              style: ElevatedButton.styleFrom(
                                backgroundColor: Colors.green,
                              ),
                              child: Text('Connect'),
                            ),
                          ),
                          SizedBox(width: 8),
                          Expanded(
                            child: ElevatedButton(
                              onPressed: isConnected ? disconnect : null,
                              style: ElevatedButton.styleFrom(
                                backgroundColor: Colors.red,
                              ),
                              child: Text('Disconnect'),
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
              ),
              
              SizedBox(height: 20),
              
              // Speed Control
              Card(
                color: Colors.blueGrey[800],
                child: Padding(
                  padding: EdgeInsets.all(16.0),
                  child: Column(
                    children: [
                      Text(
                        'Speed: ${speed.round()}',
                        style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                      ),
                      Slider(
                        value: speed,
                        min: 0,
                        max: 255,
                        divisions: 25,
                        onChanged: isConnected ? (value) {
                          setState(() {
                            speed = value;
                          });
                        } : null,
                        onChangeEnd: (value) {
                          sendSpeedCommand();
                        },
                      ),
                    ],
                  ),
                ),
              ),
              
              SizedBox(height: 20),
              
              // Car Controls
              Expanded(
                child: Card(
                  color: Colors.blueGrey[800],
                  child: Padding(
                    padding: EdgeInsets.all(16.0),
                    child: Column(
                      children: [
                        // Forward button
                        Expanded(
                          child: SizedBox(
                            width: double.infinity,
                            child: GestureDetector(
                              onTapDown: (_) {
                                setState(() { forward = true; });
                                sendMoveCommand();
                              },
                              onTapUp: (_) {
                                setState(() { forward = false; });
                                sendMoveCommand();
                              },
                              onTapCancel: () {
                                setState(() { forward = false; });
                                sendMoveCommand();
                              },
                              child: Container(
                                decoration: BoxDecoration(
                                  color: forward ? Colors.green : Colors.grey[700],
                                  borderRadius: BorderRadius.circular(8),
                                ),
                                child: Icon(
                                  Icons.keyboard_arrow_up,
                                  size: 50,
                                  color: Colors.white,
                                ),
                              ),
                            ),
                          ),
                        ),
                        
                        SizedBox(height: 8),
                        
                        // Left, Stop, Right buttons
                        Expanded(
                          child: Row(
                            children: [
                              Expanded(
                                child: GestureDetector(
                                  onTapDown: (_) {
                                    setState(() { left = true; });
                                    sendMoveCommand();
                                  },
                                  onTapUp: (_) {
                                    setState(() { left = false; });
                                    sendMoveCommand();
                                  },
                                  onTapCancel: () {
                                    setState(() { left = false; });
                                    sendMoveCommand();
                                  },
                                  child: Container(
                                    height: double.infinity,
                                    decoration: BoxDecoration(
                                      color: left ? Colors.blue : Colors.grey[700],
                                      borderRadius: BorderRadius.circular(8),
                                    ),
                                    child: Icon(
                                      Icons.keyboard_arrow_left,
                                      size: 50,
                                      color: Colors.white,
                                    ),
                                  ),
                                ),
                              ),
                              
                              SizedBox(width: 8),
                              
                              Expanded(
                                child: GestureDetector(
                                  onTap: emergencyStop,
                                  child: Container(
                                    height: double.infinity,
                                    decoration: BoxDecoration(
                                      color: Colors.red[700],
                                      borderRadius: BorderRadius.circular(8),
                                    ),
                                    child: Column(
                                      mainAxisAlignment: MainAxisAlignment.center,
                                      children: [
                                        Icon(Icons.stop, size: 30, color: Colors.white),
                                        Text('STOP', style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold)),
                                      ],
                                    ),
                                  ),
                                ),
                              ),
                              
                              SizedBox(width: 8),
                              
                              Expanded(
                                child: GestureDetector(
                                  onTapDown: (_) {
                                    setState(() { right = true; });
                                    sendMoveCommand();
                                  },
                                  onTapUp: (_) {
                                    setState(() { right = false; });
                                    sendMoveCommand();
                                  },
                                  onTapCancel: () {
                                    setState(() { right = false; });
                                    sendMoveCommand();
                                  },
                                  child: Container(
                                    height: double.infinity,
                                    decoration: BoxDecoration(
                                      color: right ? Colors.blue : Colors.grey[700],
                                      borderRadius: BorderRadius.circular(8),
                                    ),
                                    child: Icon(
                                      Icons.keyboard_arrow_right,
                                      size: 50,
                                      color: Colors.white,
                                    ),
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                        
                        SizedBox(height: 8),
                        
                        // Backward button
                        Expanded(
                          child: SizedBox(
                            width: double.infinity,
                            child: GestureDetector(
                              onTapDown: (_) {
                                setState(() { backward = true; });
                                sendMoveCommand();
                              },
                              onTapUp: (_) {
                                setState(() { backward = false; });
                                sendMoveCommand();
                              },
                              onTapCancel: () {
                                setState(() { backward = false; });
                                sendMoveCommand();
                              },
                              child: Container(
                                decoration: BoxDecoration(
                                  color: backward ? Colors.orange : Colors.grey[700],
                                  borderRadius: BorderRadius.circular(8),
                                ),
                                child: Icon(
                                  Icons.keyboard_arrow_down,
                                  size: 50,
                                  color: Colors.white,
                                ),
                              ),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}